from project.mammal import Mammal


class Gorilla(Mammal):
    # pass
    def __init__(self, name):
        super().__init__(name)