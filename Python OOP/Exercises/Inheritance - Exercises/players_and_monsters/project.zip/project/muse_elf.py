from project.elf import Elf


class MuseElf(Elf):
    # pass
    def __init__(self, user_name, level):
        super().__init__(user_name, level)