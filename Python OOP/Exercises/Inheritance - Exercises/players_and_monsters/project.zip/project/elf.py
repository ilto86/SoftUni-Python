from project.hero import Hero


class Elf(Hero):
    # pass
    def __init__(self, user_name, level):
        super().__init__(user_name, level)