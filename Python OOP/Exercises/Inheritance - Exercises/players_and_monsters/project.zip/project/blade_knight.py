from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    # pass
    def __init__(self, user_name, level):
        super().__init__(user_name, level)