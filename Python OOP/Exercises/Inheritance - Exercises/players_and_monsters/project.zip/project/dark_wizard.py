from project.wizard import Wizard


class DarkWizard(Wizard):
    # pass
    def __init__(self, user_name, level):
        super().__init__(user_name, level)