from project.dark_wizard import DarkWizard


class SoulMaster(DarkWizard):
    # pass
    def __init__(self, user_name, level):
        super().__init__(user_name, level)