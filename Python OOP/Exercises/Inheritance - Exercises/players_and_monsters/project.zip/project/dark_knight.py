from project.knight import Knight


class DarkKnight(Knight):
    # pass
    def __init__(self, user_name, level):
        super().__init__(user_name, level)